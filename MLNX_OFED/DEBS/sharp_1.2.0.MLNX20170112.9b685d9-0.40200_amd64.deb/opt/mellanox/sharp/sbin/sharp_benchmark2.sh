#!/bin/bash -e
#
# Copyright (C) Mellanox Technologies Ltd. 2016.  ALL RIGHTS RESERVED.
# See file LICENSE for terms.
#

. $(dirname $0)/sharp_funcs.sh

usage()
{
	echo "Usage: `basename $0` [-t] [-d] [-s] [-h]"
	echo "	-t - tests list"
	echo "	-d - dry run"
	echo "	-s - also start SHArP daemons"
	echo "	-h - This help"

	exit 2
}

allreduce=1
barrier=1
sharp_allreduce=1
sharp_barrier=1

while getopts "sdt:h" flag_arg; do
	case $flag_arg in
		s)	start_it=1 ;;
		d)  dryrun=1   ;;
		t)	allreduce=
			barrier=
			sharp_allreduce=
			sharp_barrier=

			for x in $OPTARG; do
				case $x in
					allreduce)       allreduce=1       ;;
					barrier)         barrier=1         ;;
					sharp:allreduce) sharp_allreduce=1 ;;
					sharp:barrier)   sharp_barrier=1   ;;
					*)               echo "Unknown parameter: $x"
									 usage ;;
				esac
			done ;;
		h) usage ;;
		*) usage ;;

	esac
done

sharp_install=${sharp_install:-$(readlink -f $(dirname $0)/..)}
if [ ! -d "$sharp_install" ]; then
    echo "Unable to find SHArP dir. Exit."
    exit 1
fi

if [ -f $sharp_install/../modulefiles/hpcx ]; then
	module load $sharp_install/../modulefiles/hpcx
elif module whatis hpcx-gcc 2>&1 | grep -q HPC-X; then
	module load hpcx-gcc
fi

#
# Run SHArP daemnons
#
if [ -w $sharp_install ]; then
	_local_dir=$sharp_install
else
	_local_dir=$HOME/sharp_conf
fi

DCONF_DIR=$_local_dir/conf
OUT_AM=/tmp/d_sharp_am.log
OUT_SD=/tmp/d_sharpd.log
AM_CFG=$DCONF_DIR/sharp_am.cfg
SD_CFG=$DCONF_DIR/sharpd.cfg


# Run SHArP daemons
[ -n "$start_it" ] && ( $(dirname $0)/sharp_manager.sh -o restart || exit 1 )
load_params

if [ -z "$sharp_benchmark_hostlist" ] || [ -z "$sharp_benchmark_hca" ]; then
	echo "'sharp_benchmark_hostlist' and 'sharp_benchmark_hca' can't be empty. Exit."
	exit 1
fi

#
# Run OMPI tests
#
mpirun="$OMPI_HOME/bin/mpirun"
test_iters=10000
test_skip_iters=1000
bind_to_core=" taskset -c 1 numactl --membind=0 "
nnodes=$(echo $sharp_benchmark_hostlist | awk -F, '{print NF}')
hostfile=/tmp/hostfile.$$

rm -f $hostfile &> /dev/null
(IFS=',';for node in $sharp_benchmark_hostlist; do echo $node >> $hostfile; done)

np=$((sharp_benchmark_ppn * nnodes))

opt="--bind-to core --map-by node -hostfile $hostfile -np $np "
#	opt+=" --display-map "
opt+=" -mca pml yalla "
opt+=" -mca btl_openib_warn_default_gid_prefix 0 "
opt+=" -mca rmaps_dist_device $sharp_benchmark_hca -mca rmaps_base_mapping_policy dist:span "
opt+=" -x MXM_RDMA_PORTS=$sharp_benchmark_hca -x HCOLL_MAIN_IB=$sharp_benchmark_hca "
opt+=" -x MXM_LOG_LEVEL=ERROR "
opt+=" -x HCOLL_ML_DISABLE_REDUCE=1 "
opt+=" -x HCOLL_ENABLE_MCAST_ALL=1 "
opt+=" -x HCOLL_MCAST_NP=1 "
opt+=" -x LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$sharp_install/lib "
opt+=" -x LD_PRELOAD=$sharp_install/lib/libsharp.so:$sharp_install/lib/libsharp_coll.so "

osu_allreduce_exe=$(find $OMPI_HOME/tests/osu* -name osu_allreduce)
osu_barrier_exe=$(find $OMPI_HOME/tests/osu* -name osu_barrier)

if [ "$sharp_benchmark_ppn" -eq "1" ]; then
	osu_allreduce_exe="$bind_to_core $osu_allreduce_exe"
	osu_barrier_exe="$bind_to_core $osu_barrier_exe"
fi
osu_opt="-i $test_iters -x $test_skip_iters -f"

MAX_PAYLOAD_SIZE=256

hcoll_sharp_opt=" -x HCOLL_ENABLE_SHARP=2 " # Enables sharp without fallback
hcoll_sharp_opt+=" -x SHARP_COLL_LOG_LEVEL=3  " # Enables libsharp logging
hcoll_sharp_opt+=" -x SHARP_COLL_GROUP_RESOURCE_POLICY=1 " # OSU runs only one communicator
#	hcoll_sharp_opt+=" -x SHARP_COLL_ENABLE_MCAST_TARGET=1 " # UD MCAST. By default : enabled
#	hcoll_sharp_opt+=" -x SHARP_COLL_GROUP_IS_TARGET=1 " # Enable RC distribution. By default : enabled
#	hcoll_sharp_opt+=" -x SHARP_COLL_ENABLE_GROUP_TRIM=1 " # SHArP group tim. By default : enabled
hcoll_sharp_opt+=" -x SHARP_COLL_MAX_PAYLOAD_SIZE=$MAX_PAYLOAD_SIZE" # Maximum payload size of sharp collective request. 256 is max.
hcoll_sharp_opt+=" -x HCOLL_SHARP_UPROGRESS_NUM_POLLS=999 "
hcoll_sharp_opt+=" -x HCOLL_BCOL_P2P_ALLREDUCE_SHARP_MAX=4096 "
hcoll_sharp_opt+=" -x SHARP_COLL_PIPELINE_DEPTH=32 " # Size of fragmentation pipeline for larger collective payload
#	hcoll_sharp_opt+=" -x SHARP_COLL_POLL_BATCH=1 " # How many CQ completions to poll on at once. Maximum:16
# Job quota
hcoll_sharp_opt+=" -x SHARP_COLL_JOB_QUOTA_OSTS=32 " # OST quota request. value 0 mean allocate default quota.
hcoll_sharp_opt+=" -x SHARP_COLL_JOB_QUOTA_MAX_GROUPS=4 "
hcoll_sharp_opt+=" -x SHARP_COLL_JOB_QUOTA_PAYLOAD_PER_OST=$MAX_PAYLOAD_SIZE " # Maximum payload per OST quota request. value 256 is max

MPI_LOG=$log_save_dir/sharp_log_mpirun.log
TIME_LOG=$log_save_dir/sharp_log_times.log

echo "Started " $(date +"%d.%m.%Y %H:%M:%S") > $TIME_LOG

run_cmd()
{
	_test=$1
	_cmd=$2

	if [ -n "$_test" ]; then
		echo -e "$_cmd"
		[ -z "$dryrun" ] && ( $_cmd 2>&1 | tee -a $MPI_LOG )
		echo ""
	fi
}

if [ -n "$sharp_allreduce" ] || [ -n "$sharp_barrier" ]; then
	printf "\n\n....................................................\n"
	printf "   with SHArP\n"
	printf "....................................................\n"
fi
run_cmd "$sharp_allreduce" "$mpirun $opt $hcoll_sharp_opt $osu_allreduce_exe $osu_opt"
run_cmd "$sharp_barrier"   "$mpirun $opt $hcoll_sharp_opt $osu_barrier_exe $osu_opt"

if [ -n "$allreduce" ] || [ -n "$barrier" ]; then
	printf "\n\n....................................................\n"
	printf "   withOUT SHArP\n"
	printf "....................................................\n"
fi
run_cmd "$allreduce" "$mpirun $opt $osu_allreduce_exe $osu_opt"
run_cmd "$barrier"   "$mpirun $opt $osu_barrier_exe $osu_opt"

rm -f $hostfile &> /dev/null

echo "Finished " $(date +"%d.%m.%Y %H:%M:%S") >> $TIME_LOG

[ -n "$start_it" ] && $(dirname $0)/sharp_manager.sh -o logs
