#!/bin/bash
#
# Copyright (C) Mellanox Technologies Ltd. 2016.  ALL RIGHTS RESERVED.
# See file LICENSE for terms.
#

. $(dirname $0)/sharp_funcs.sh

set_param()
{
	_param=$1
	_var=$2
	_val=$3

	read -p "$_param [$_val]: " res
	[ -z "$res" ] && res=$_val
	echo -e "The answer is: $res\n"

	[ -n "$res" ] && eval $_var=$res

	return 0
}

PREFIX="sharp_manager"
STEPS="am_server hca root_guids_file fabric_lst_file sharpd_log_level sharp_am_log_level"

load_params $PREFIX

echo "...................................................."
echo "   Please set values for the following parameters:"
echo -e "....................................................\n"

for x in $STEPS ; do
	name=${PREFIX}_$x
    set_param $x $name ${!name}
done

set_local_params

read -p "Would you like to start SHArP with these parameters [y/n]? " res
( [ "$res" = "y" ] || [ "$res" = "Y" ] ) && $(dirname $0)/sharp_manager.sh -o start
