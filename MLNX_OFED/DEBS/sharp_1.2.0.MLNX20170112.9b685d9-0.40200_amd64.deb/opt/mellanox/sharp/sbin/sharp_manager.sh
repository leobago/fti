#!/bin/bash -e
#
# Copyright (C) Mellanox Technologies Ltd. 2016.  ALL RIGHTS RESERVED.
# See file LICENSE for terms.
#

. $(dirname $0)/sharp_funcs.sh

usage()
{
	echo "Usage: `basename $0` <-o start/restart/stop/status/set/logs/ver> [-l hostlist] [-d hca:port] [-s am_server] [-f fabric_lst_file] [-r root_guids_file] [-h]"
	echo "	-o - operation start/stop/status/set/logs/ver"
	echo "	        'start/restart/stop/status' - apply to SHArP daemons"
	echo "	        'set'  - set SHArP daemons runtime parameters"
	echo "	        'logs' - collect log from SHArP daemons"
	echo "	        'ver'  - show version of SHArP daemons"
	echo "	-l - Compute nodes host list"
	echo "	-d - device (hca:port)"
	echo "	-s - AM server hostname"
	echo "	-f - Path to fabric_lst_file"
	echo "	-r - Path to root_guids_file"
	echo "	-h - This help"

	exit 2
}

make_conf()
{
	_CFG=$1
	_TMP=$2
	_NAME=$3

	if [ -f $_TMP ] && [ -f $_CFG ] && ! diff $_TMP $_CFG &> /dev/null; then
		save_to=$DCONF_DIR/${_NAME}_${_time}.cfg

		echo "Conf file $_CFG will be saved to $save_to"
		cp $_CFG $save_to
	fi

	mv -f $_TMP $_CFG
}

build_conf()
{
	if [ ! -w $sharp_install ]; then
		echo "Unable to write to $sharp_install. Exit"
		exit 1
	fi

	TMP_AM=/tmp/sharp_am_$$.cfg
	TMP_SD=/tmp/sharpd_$$.cfg

	cat > $TMP_AM << EOF
log_verbosity $sharp_manager_sharp_am_log_level
fabric_lst_file $sharp_manager_fabric_lst_file
root_guids_file $sharp_manager_root_guids_file
EOF

	cat > $TMP_SD << EOF
log_verbosity $sharp_manager_sharpd_log_level
ib_dev $sharp_manager_hca
EOF

	_time=$(date +%d%m%y_%H:%M)
	make_conf $AM_CFG $TMP_AM "sharp_am"
	make_conf $SD_CFG $TMP_SD "sharpd"
}

_confs()
{
	DCONF_DIR=$sharp_install/conf
	OUT_AM=/tmp/d_sharp_am.log
	OUT_SD=/tmp/d_sharpd.log
	AM_CFG=$DCONF_DIR/sharp_am.cfg
	SD_CFG=$DCONF_DIR/sharpd.cfg

	mkdir -p $DCONF_DIR
}

collect_logs()
{
	_confs

	LOG_DIR=$sharp_manager_log_save_dir/sharp_logs.$$
	mkdir -p $LOG_DIR

	cp $sharp_manager_log_save_dir/sharp_log*.log $LOG_DIR &> /dev/null
	cp -R $DCONF_DIR $LOG_DIR &> /dev/null
	scp $sharp_manager_am_server:/var/log/sharp_am.log $LOG_DIR &> /dev/null
	scp $sharp_manager_am_server:$OUT_AM $LOG_DIR &> /dev/null
	$_pdsh -w $sharp_manager_hostlist "scp /var/log/sharpd.log $HOSTNAME:$LOG_DIR/sharpd_%h.log" &> /dev/null
	$_pdsh -w $sharp_manager_hostlist "scp $OUT_SD $HOSTNAME:$LOG_DIR/$(basename $OUT_SD)_%h.log" &> /dev/null

	echo "Logs location is $HOSTNAME:$LOG_DIR"
}

all_run()
{
	AM_COMM="$1"
	SD_COMM="$2"

	sudo ssh -t $sharp_manager_am_server "sleep 2; ENV="$_ENV" SHARP_CONF="$sharp_install" nohup $AM_COMM &> $OUT_AM; sleep 2" &> /dev/null && sleep 5
	sudo $_pdsh -w $sharp_manager_hostlist "ENV="$_ENV" SHARP_CONF="$sharp_install" nohup $SD_COMM &> $OUT_SD" &> /dev/null && sleep 3
}

start()
{
	_confs

	if [ -z "$sharp_manager_hca" ]; then
		echo "Please set 'sharp_manager_hca' parameter. Exit."
		exit 1
	fi

	build_conf

	echo "SHArP config dir: $(readlink -f $sharp_install)/conf"
	echo "Startup SHArP daemons..."
	all_run	"$sharp_install/etc/sharp_am start" "$sharp_install/etc/sharpd start"
}

stop()
{
	_confs

	echo "Stopping SHArP daemons..."
	all_run	"$sharp_install/etc/sharp_am stop" "$sharp_install/etc/sharpd stop"

	sudo ssh $sharp_manager_am_server "pkill sharp_am; rm -f $OUT_AM /var/run/sharp_am.pid"
	sudo $_pdsh -w $sharp_manager_hostlist "pkill sharpd; rm -f $OUT_SD /var/run/sharpd.pid"
}

status()
{
	cnt1=$((sudo ssh $sharp_manager_am_server "$sharp_install/etc/sharp_am status" | grep "is running" | wc -l) 2>/dev/null)
	if [ $cnt1 -eq 1 ]; then
		echo "sharp_am is UP"
		ret_am=0
	else
		echo "sharp_am is DOWN."
		ret_am=1
	fi

	cnt1=$((sudo $_pdsh -w $sharp_manager_hostlist "$sharp_install/etc/sharpd status" | grep "is running" | wc -l) 2>/dev/null)
	cnt2=$(echo $sharp_manager_hostlist | sed 's/,/ /g' | wc -w)
	if [ $cnt1 -eq $cnt2 ]; then
		echo "sharpds are UP"
		ret_d=0
	else
		echo "Some sharpd(s) is DOWN"
		sudo $_pdsh -w $sharp_manager_hostlist "$sharp_install/etc/sharpd status" 2>/dev/null
		ret_d=1
	fi

	if [ $ret_am -eq 1 ] || [ $ret_d -eq 1 ]; then
		return 1
	else
		return 0
	fi
}

show_vers()
{
	sudo ssh $sharp_manager_am_server "$sharp_install/bin/sharp_am -v | grep '(sharp)'"
	sudo $_pdsh -w $sharp_manager_hostlist "$sharp_install/bin/sharpd -v  | grep '(sharp)'"
}

#
# Main
#
load_params

while getopts "o:l:d:s:f:r:h" flag_arg; do
	case $flag_arg in
		o) operation="$OPTARG"                     ;;
		l) sharp_manager_hostlist="$OPTARG"        ;;
		d) sharp_manager_hca="$OPTARG"             ;;
		s) sharp_manager_am_server="$OPTARG"       ;;
		f) sharp_manager_fabric_lst_file="$OPTARG" ;;
		r) sharp_manager_root_guids_file="$OPTARG" ;;
		h) usage                                   ;;
		*) usage                                   ;;
	esac
done

[ "$operation" != "start" ] && [ "$operation" != "restart" ] &&
[ "$operation" != "stop" ] && [ "$operation" != "status" ] &&
[ "$operation" != "set" ] &&  [ "$operation" != "logs" ] &&
[ "$operation" != "ver" ] && usage

_pdsh=$(which pdsh 2>/dev/null)
if [ -z "$_pdsh" ]; then
	echo "pdsh not found. Exit."
	exit 1
fi

#
# Check params
#
if [ -z "$sharp_manager_am_server" ]; then
	if pgrep opensm &> /dev/null; then
		sharp_manager_am_server=$(hostname -s)
	else
		echo "Please edit this script and set am_server"
		exit 1
	fi
fi

for conf_file in "$sharp_manager_fabric_lst_file" "$sharp_manager_root_guids_file" ; do
	if [ -n "$conf_file" ] && ssh -q $sharp_manager_am_server "[[ ! -f $conf_file ]]"; then
		echo "ERROR: $conf_file is absent on $sharp_manager_am_server"
		exit 1
	fi
done

if [ -z "$sharp_manager_hostlist" ]; then
    echo "hostlist can't be empty"
    exit 1
fi
echo -e "sharp_am host:  $sharp_manager_am_server"
echo -e "sharpds' hosts: $sharp_manager_hostlist\n"

set_local_params

sharp_install=${sharp_install:-$(readlink -f $(dirname $0)/..)}
if [ ! -d "$sharp_install" ]; then
    echo "Unable to find SHArP dir. Exit."
    exit 1
fi


case $operation in
	start)  start         ;;
	restart) stop; start  ;;
	stop)   stop          ;;
	status) status        ;;
	set) set_local_params ;;
	logs)   collect_logs  ;;
	ver)    show_vers     ;;
esac

echo -e "\nAll Done"
