#!/bin/bash
#
# Copyright (C) Mellanox Technologies Ltd. 2016.  ALL RIGHTS RESERVED.
# See file LICENSE for terms.
#

if [ $(whoami) != "root" ]; then
	echo "Error: root permission required. Exit."
	exit 1
fi

distro_name=$(python -c 'import platform ; print platform.dist()[0]' | tr '[:upper:]' '[:lower:]')

add_serv()
{
	serv=$1

	case $distro_name in
		'ubuntu') update-rc.d $serv defaults &> /dev/null ;;
		*)        chkconfig --add $serv &> /dev/null      ;;
	esac
}

rm_serv()
{
	serv=$1

	case $distro_name in
		'ubuntu') (ls /etc/rc*.d | grep -q $serv) &> /dev/null && update-rc.d -f $serv remove &> /dev/null ;;
		*)        (chkconfig --list | grep $serv) &> /dev/null && chkconfig --del $serv &> /dev/null       ;;
	esac
}

unset_level()
{
	serv=$1

	case $distro_name in
		'ubuntu') update-rc.d $serv disable 0123456 &> /dev/null   ;;
		*)        chkconfig --level 0123456 $serv off &> /dev/null ;;
	esac
}

is_added()
{
	serv=$1
	ok=1

	case $distro_name in
		'ubuntu') ls /etc/rc*.d | grep -q $serv && ok=0                ;;
		*)        (chkconfig --list | grep $serv) &> /dev/null && ok=0 ;;
	esac

	if [ $ok -eq 0 ]; then
		echo "Setup of $serv is OK"
		return 0
	else
		echo "Error: failed to setup service $serv"
		return 1
	fi
}

is_removed()
{
	serv=$1
	ok=1

	case $distro_name in
		'ubuntu') ! (ls /etc/rc*.d | grep -q $serv) && ok=0              ;;
		*)        ! (chkconfig --list | grep $serv) &> /dev/null && ok=0 ;;
	esac
    
	if [ $ok -eq 0 ]; then
		echo "$serv is removed"
		return 0
	else
		echo "Error: failed to remove $serv"
		return 1
	fi
}

# $1 - service name
monit_add()
{
	SERVICE=$1
	MONIT_DIR=/etc/monit.d
	MONIT_FILE=$MONIT_DIR/${SERVICE}.conf
	TMP_F=/tmp/${SERVICE}_$$.conf
	
	if [ ! -d $MONIT_DIR ]; then
		echo "Warning: Seems like monit package is not installed. ${SERVICE} will not be monitored."
		return 1
	fi
	
	cat > $TMP_F << EOF
check process $SERVICE with pidfile /var/run/${SERVICE}.pid
	start program = "/etc/init.d/$SERVICE start"
	stop program = "/etc/init.d/$SERVICE stop"
	if 50 restarts within 50 cycles then timeout
EOF

	sudo cp $TMP_F $MONIT_FILE &> /dev/null
	sudo pkill -1 monit &> /dev/null
}

# $1 - service name
monit_remove()
{
	SERVICE=$1
	MONIT_DIR=/etc/monit.d
	MONIT_FILE=$MONIT_DIR/${SERVICE}.conf
	
	[ ! -d $MONIT_DIR ] && return 1
	
	sudo rm -f $MONIT_FILE &> /dev/null
	sudo pkill -1 monit &> /dev/null
}

# $1 - SHArP location dir
# $2 - list of daemons
# $3 - monit flag
setup()
{
	init=$1/sbin/sharp.init

	if [ ! -f "$init" ]; then
		echo "Error: $init doesn't exist. Exit."
		exit 3
	fi

	chmod 755 $init
 
	for x in $2; do
		ln -s $init /etc/init.d/$x
		add_serv $x

		[ $x = "sharp_am" ] && unset_level sharp_am

		is_added $x
		
		[ $? -eq 0 ] && [ -n "$3" ] && monit_add $x
	done
}

# $1 - list of daemons
unsetup()
{
	for x in $1; do
		[ -x /etc/init.d/$x ] && /etc/init.d/$x stop

		rm -f /etc/init.d/$x &> /dev/null
		rm_serv $x
 
		is_removed $x
		
		[ $? -eq 0 ] && monit_remove $x
	done
}

usage()
{
	echo "Usage: `basename $0` <-s> [-p SHArP location dir] <-r> <-d daemon> <-m>"
	echo "	-s - Setup SHArP daemon"
	echo "	-p - Path to alternative SHArP location dir"
	echo "	-r - Remove SHArP daemon"
	echo "	-d - Daemon name (sharpd or sharp_am)"
	echo "	-m - Add monit capability for daemon control"

	exit 2
}

dlist=""
location_dir=""
to_setup=""
to_remove=""
to_monit=""
while getopts "sp:rd:m" flag_arg; do
	case $flag_arg in
		s) to_setup="yes"         ;;
		p) location_dir="$OPTARG" ;;
		r) to_remove="yes"        ;;
		d) dlist="$OPTARG"        ;;
		m) to_monit="yes"         ;;
		*) usage                  ;;
	esac
done

([ $OPTIND -eq 1 ] || [ -z "$dlist" ]) && usage

[ -z "$location_dir" ] && _dir=$(readlink -f $(dirname $0)/..)

for x in $dlist; do
	([ $x != "sharpd" ] && [ $x != "sharp_am" ]) && usage
	
	[ -z "$location_dir" ] && [ -f "$_dir/bin/$x" ] && location_dir=$_dir
done

[ -n "$to_setup" ] && setup "$location_dir" "$dlist" "$to_monit"
[ -n "$to_remove" ] && unsetup "$dlist"

exit 0
