#!/bin/bash
#
# Copyright (C) Mellanox Technologies Ltd. 2016.  ALL RIGHTS RESERVED.
# See file LICENSE for terms.
#

############ ADJUST FOLLOWING VALUES ############################
ppn=${ppn:-"1"}
hostlist=${hostlist:=""}
hca=${hca:=""}
am_server=${am_server:=""}
sharp_install=
sharpd_log_level=5
sharp_am_log_level=3
log_save_dir=/var/tmp
fabric_lst_file="/var/log/opensm-subnet.lst"
root_guids_file=""
#################################################################

# glibc malloc checker (disabled)
MALLOC_CHECK_=
MAX_PAYLOAD_SIZE=256

allreduce=1
barrier=1
sharp_allreduce=1
sharp_barrier=1
test_only=1

while getopts "stT:" flag_arg; do
	case $flag_arg in
		s)	start_only=1
			test_only=0
			;;

		t)	test_only=1
			;;

		T)	test_only=1
			allreduce=
			barrier=
			sharp_allreduce=
			sharp_barrier=

			for x in $OPTARG; do
				case $x in
					allreduce)       allreduce=1       ;;
					barrier)         barrier=1         ;;
					sharp:allreduce) sharp_allreduce=1 ;;
					sharp:barrier)   sharp_barrier=1   ;;
					*)               echo "Unknown parameter: $x"
					                 exit 0
                                     ;;
				esac
			done
			;;
	esac
done

#
# Check params
#
if [ -z "$am_server" ]; then
	if pgrep opensm &> /dev/null; then
		am_server=$(hostname -s)
	else
		echo "Please edit this script and set am_server"
		exit 1
	fi
fi

if [ -z "$root_guids_file" ] && (( $test_only != 1 )); then
	echo "Please edit this script and set root_guids_file"
	exit 1
fi

if [ -z "$hca" ]; then
	echo "Please set hca"
	exit 1
fi

if (( $test_only != 1 )); then
	for conf_file in "$fabric_lst_file" "$root_guids_file" ; do
		if ssh -q $am_server "[[ ! -f $conf_file ]]"; then
			echo "ERROR: $conf_file is absent on $am_server"
			exit 1
		fi
	done
fi

if [ -z "$SLURM_NODELIST" ] && [ $(squeue 2>/dev/null | grep $(whoami) | wc -l) -eq 1 ]; then
	SLURM_NODELIST=$(squeue 2>/dev/null | grep $(whoami) | awk '{print $NF}')
fi
[ -n "$SLURM_NODELIST" ] && hostlist=$(hostlist -e $SLURM_NODELIST -s,)

if [ -z "$hostlist" ]; then
    echo "hostlist can't be empty"
    exit 1
fi
echo "Using hostlist: $hostlist"


sharp_install=${sharp_install:-$(readlink -f $(dirname $0)/..)}
if [ ! -d "$sharp_install" ]; then
    echo "Unable to find SHArP dir. Exit."
    exit 1
fi

if [ -f $sharp_install/../modulefiles/hpcx ]; then
	module load $sharp_install/../modulefiles/hpcx
elif module whatis hpcx-gcc 2>&1 | grep -q HPC-X; then
	module load hpcx-gcc
fi

#
# Run SHArP daemnons
#
if [ -w $sharp_install ]; then
	_local_dir=$sharp_install
else
	_local_dir=$HOME/sharp_conf
fi

DCONF_DIR=$_local_dir/conf
OUT_AM=/tmp/d_sharp_am.log
OUT_SD=/tmp/d_sharpd.log
AM_CFG=$DCONF_DIR/sharp_am.cfg
SD_CFG=$DCONF_DIR/sharpd.cfg

if (( $test_only != 1 )); then
	echo "SHArP config dir: $(readlink -f $_local_dir)/conf"
	printf "Startup SHArP daemons..."

	mkdir -p $DCONF_DIR

	cat > $AM_CFG << EOF
log_verbosity $sharp_am_log_level
fabric_lst_file $fabric_lst_file
root_guids_file $root_guids_file
EOF

	cat > $SD_CFG << EOF
log_verbosity $sharpd_log_level
ib_dev $hca
EOF

	START_AM="$sharp_install/etc/sharp_am start"
	START_SD="$sharp_install/etc/sharpd start"

	_pdsh=$(which pdsh)

	[ -n "$MALLOC_CHECK_" ] && _ENV="MALLOC_CHECK_=$MALLOC_CHECK_"

	sudo ssh $am_server "pkill sharp_am; rm -f $OUT_AM /var/run/sharp_am.pid"
	sudo ssh -t $am_server "sleep 2; ENV="$_ENV" SHARP_CONF="$_local_dir" nohup $START_AM &> $OUT_AM; sleep 2" &> /dev/null && sleep 5

	sudo $_pdsh -w $hostlist "pkill sharpd; rm -f $OUT_SD /var/run/sharpd.pid"
	sudo $_pdsh -w $hostlist "ENV="$_ENV" SHARP_CONF="$_local_dir" nohup $START_SD &> $OUT_SD" &> /dev/null && sleep 3

	cnt1=$((sudo ssh $am_server "$sharp_install/etc/sharp_am status" | grep "is running" | wc -l) 2>/dev/null)
	if [ $cnt1 -ne 1 ]; then
		echo "Unable to start sharp_am. Exit."
		exit 1
	fi

	cnt1=$((sudo $_pdsh -w $hostlist "$sharp_install/etc/sharpd status" | grep "is running" | wc -l) 2>/dev/null)
	cnt2=$(echo $hostlist | sed 's/,/ /g' | wc -w)
	if [ $cnt1 -ne $cnt2 ]; then
		echo "Unable to start sharpds. Exit."
		exit 1
	fi

	echo " Done"
fi

if [ -z "$start_only" ]; then
#
# Run OMPI tests
#
	mpirun="$OMPI_HOME/bin/mpirun"
	test_iters=10000
	test_skip_iters=1000
	bind_to_core=" taskset -c 1 numactl --membind=0 "
	nnodes=$(echo $hostlist | awk -F, '{print NF}')
	hostfile=/tmp/hostfile.$$

    rm -f $hostfile &> /dev/null
    (IFS=',';for node in $hostlist; do echo $node >> $hostfile; done)

	np=$((ppn*nnodes))

	opt="--bind-to core --map-by node -hostfile $hostfile -np $np "
	#	opt+=" --display-map "
	opt+=" -mca pml yalla "
	opt+=" -mca btl_openib_warn_default_gid_prefix 0 "
	opt+=" -mca rmaps_dist_device $hca -mca rmaps_base_mapping_policy dist:span "
	opt+=" -x MXM_RDMA_PORTS=$hca -x HCOLL_MAIN_IB=$hca "
	opt+=" -x MXM_LOG_LEVEL=ERROR "
	opt+=" -x HCOLL_ML_DISABLE_REDUCE=1 "
	opt+=" -x HCOLL_ENABLE_MCAST_ALL=1 "
	opt+=" -x HCOLL_MCAST_NP=1 "
	opt+=" -x LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$sharp_install/lib "
	opt+=" -x LD_PRELOAD=$sharp_install/lib/libsharp.so:$sharp_install/lib/libsharp_coll.so "

	osu_allreduce_exe=$(find $OMPI_HOME/tests/osu* -name osu_allreduce)
	osu_barrier_exe=$(find $OMPI_HOME/tests/osu* -name osu_barrier)

	if [ "$ppn" -eq "1" ]; then
		osu_allreduce_exe="$bind_to_core $osu_allreduce_exe"
		osu_barrier_exe="$bind_to_core $osu_barrier_exe"
	fi
	osu_opt="-i $test_iters -x $test_skip_iters -f"

	hcoll_sharp_opt=" -x HCOLL_ENABLE_SHARP=2 " # Enables sharp without fallback
	hcoll_sharp_opt+=" -x SHARP_COLL_LOG_LEVEL=3  " # Enables libsharp logging
	hcoll_sharp_opt+=" -x SHARP_COLL_GROUP_RESOURCE_POLICY=1 " # OSU runs only one communicator
	#	hcoll_sharp_opt+=" -x SHARP_COLL_ENABLE_MCAST_TARGET=1 " # UD MCAST. By default : enabled
	#	hcoll_sharp_opt+=" -x SHARP_COLL_GROUP_IS_TARGET=1 " # Enable RC distribution. By default : enabled
	#	hcoll_sharp_opt+=" -x SHARP_COLL_ENABLE_GROUP_TRIM=1 " # SHArP group tim. By default : enabled
	hcoll_sharp_opt+=" -x SHARP_COLL_MAX_PAYLOAD_SIZE=$MAX_PAYLOAD_SIZE" # Maximum payload size of sharp collective request. 256 is max.
	hcoll_sharp_opt+=" -x HCOLL_SHARP_UPROGRESS_NUM_POLLS=999 "
	hcoll_sharp_opt+=" -x HCOLL_BCOL_P2P_ALLREDUCE_SHARP_MAX=4096 "
	hcoll_sharp_opt+=" -x SHARP_COLL_PIPELINE_DEPTH=32 " # Size of fragmentation pipeline for larger collective payload
	#	hcoll_sharp_opt+=" -x SHARP_COLL_POLL_BATCH=1 " # How many CQ completions to poll on at once. Maximum:16
	# Job quota
	hcoll_sharp_opt+=" -x SHARP_COLL_JOB_QUOTA_OSTS=32 " # OST quota request. value 0 mean allocate default quota.
	hcoll_sharp_opt+=" -x SHARP_COLL_JOB_QUOTA_MAX_GROUPS=4 "
	hcoll_sharp_opt+=" -x SHARP_COLL_JOB_QUOTA_PAYLOAD_PER_OST=$MAX_PAYLOAD_SIZE " # Maximum payload per OST quota request. value 256 is max

	LOG_DIR=$log_save_dir/sharp_logs.$$
	SHARP_MPI_LOG=$LOG_DIR/mpirun_out.log
	mkdir -p $LOG_DIR
	echo "Started " $(date +"%d.%m.%Y %H:%M:%S") > $LOG_DIR/times

	if [ -n "$sharp_allreduce" ] || [ -n "$sharp_barrier" ]; then
		printf "\n\n....................................................\n"
		printf "   with SHArP\n"
		printf "....................................................\n"
	fi
	[ -n "$sharp_allreduce" ] && ( set -x; $mpirun $opt $hcoll_sharp_opt $osu_allreduce_exe $osu_opt 2>&1 | tee -a $SHARP_MPI_LOG )
	[ -n "$sharp_barrier" ]   && ( set -x; $mpirun $opt $hcoll_sharp_opt $osu_barrier_exe   $osu_opt 2>&1 | tee -a $SHARP_MPI_LOG )

	if [ -n "$allreduce" ] || [ -n "$barrier" ]; then
		printf "\n\n....................................................\n"
		printf "   withOUT SHArP\n"
		printf "....................................................\n"
	fi
	[ -n "$allreduce" ] && ( set -x; $mpirun $opt $osu_allreduce_exe $osu_opt )
	[ -n "$barrier" ]   && ( set -x; $mpirun $opt $osu_barrier_exe   $osu_opt )

	rm -f $hostfile &> /dev/null

	echo "Finished " $(date +"%d.%m.%Y %H:%M:%S") >> $LOG_DIR/times

	#
	# Collect daemons' logs
	#
	cp -R $DCONF_DIR $LOG_DIR &> /dev/null
	scp $am_server:/var/log/sharp_am.log $LOG_DIR &> /dev/null
	scp $am_server:$OUT_AM $LOG_DIR &> /dev/null
	$_pdsh -w $hostlist "scp /var/log/sharpd.log $HOSTNAME:$LOG_DIR/sharpd_%h.log" &> /dev/null
	$_pdsh -w $hostlist "scp $OUT_SD $HOSTNAME:$LOG_DIR/$(basename $OUT_SD)_%h.log" &> /dev/null

	printf "\n\nLogs location is $HOSTNAME:$LOG_DIR\n\n\n"
fi
