/* common/knem_config.h.  Generated from knem_config.h.in by configure.  */
/* common/knem_config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to enable debug features in the driver */
/* #undef KNEM_DRIVER_DEBUG */

/* Define to enable hwloc in user-space tools */
#define KNEM_HAVE_HWLOC 1

/* Name of package */
#define PACKAGE "knem"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "knem-devel@lists.gforge.inria.fr"

/* Define to the full name of this package. */
#define PACKAGE_NAME "knem"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "knem 1.1.2.90mlnx2"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "knem"

/* Define to the home page for this package. */
#define PACKAGE_URL "http://knem.gforge.inria.fr"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.1.2.90mlnx2"

/* Version number of package */
#define VERSION "1.1.2.90mlnx2"
