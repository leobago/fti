#!/bin/bash

rm -f $0
exit 0
