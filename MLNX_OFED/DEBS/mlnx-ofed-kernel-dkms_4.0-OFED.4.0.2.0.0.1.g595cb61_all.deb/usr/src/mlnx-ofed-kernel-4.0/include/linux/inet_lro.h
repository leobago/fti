#ifndef _COMPAT_LINUX_INET_LRO_H
#define _COMPAT_LINUX_INET_LRO_H 1

#include "../../compat/config.h"

#ifdef HAVE_INET_LRO_H
#include_next <linux/inet_lro.h>
#endif

#endif	/* _COMPAT_LINUX_INET_LRO_H */
